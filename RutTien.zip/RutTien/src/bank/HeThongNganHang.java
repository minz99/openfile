package bank;

import java.util.ArrayList;
import java.util.List;

public class HeThongNganHang {
	private List<TaiKhoanNganHang> dsTK;
	public HeThongNganHang() {
		dsTK = new ArrayList<>();
	}
	public boolean themTK(TaiKhoanNganHang taiKhoanNganHang) {
		return dsTK.add(taiKhoanNganHang);
	}
}
