package bank;
import java.util.Scanner;

public class BoDieuKhienRutTien {
	protected double soDu;
	public BoDieuKhienRutTien(double soDu) {
		this.soDu = soDu;
	}
	
	public void boDieuKhien() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap so tien can rut: ");
		double soTienRut = sc.nextDouble();
		
		int ketqua = rutTien(soTienRut);
		
		switch (ketqua) {
			case 0:
				System.out.println("So du khong du");
				break;
			case 1:
				System.out.println("So tien vuot qua so du");
				break;
			case 2:
				System.out.println("Rut thanh cong");
				break;
			default:
				System.out.println("Loi he thong");
				break;
		}
		sc.close();
	}
	
	public int rutTien(double soTienRut) {
		if(soDu <= 0) return 0;
		else {
			double temp = soDu - soTienRut;
			if(temp < 50)
				return 1;
			else {
				soDu = temp;
				return 2;
			}	
		}
	}
}
