package bank;

public class TaiKhoanNganHang {
	protected String soTK;
	protected String matKhau;
	public TaiKhoanNganHang(String soTK, String matKhau) {
		this.soTK = soTK;
		this.matKhau = matKhau;
	}
	
	public String getSoTK() {
		return soTK;
	}
	public String getMatKhau() {
		return matKhau;
	}
}
