package bank;

public class ThongTinTheNganHang {
	protected String soTK;
	protected String tenTK;
	protected String CMT;
	public ThongTinTheNganHang(String soTK, String tenTK, String CMT) {
		this.soTK = soTK;
		this.tenTK = tenTK;
		this.CMT = CMT;
	}
	
	public String getSoTK() {
		return soTK;
	}
	
	public String getCMT() {
		return CMT;
	}
}
