package bank;

import java.util.Date;

public class NguoiDung {
	
	protected String tenND;
	protected String CMT;
	protected Date ngaySinh;
	protected boolean gioiTinh;
	protected String SDT;
	
	public NguoiDung(String tenND, String CMT, Date ngaySinh, boolean gioiTinh, String SDT) {
		this.tenND = tenND;
		this.CMT = CMT;
		this.ngaySinh = ngaySinh;
		this.gioiTinh = gioiTinh;
		this.SDT = SDT;
	}
	
	public String getTenND() {
		return tenND;
	}
	
	public String getCMT() {
		return CMT;
	}
	
	public Date getNgaySinh() {
		return ngaySinh;
	}
	
	public boolean getGioiTinh() {
		return gioiTinh;
	}
	
	public String getSDT() {
		return SDT;
	}
}
